const Sequelize = require("sequelize");
const app = require("./app");
const port = process.env.Port || 3979;
const {
  API_VERSION,
  IP_SERVER,
  IP_DB,
  NAME_DB,
  USER_DB,
  PASS_DB,
  DIALECT_DB,
} = require("./config");

//const sequelize = new Sequelize("postgres://user:pass@example.com:5432/dbname");

const sequelize = new Sequelize(`${NAME_DB}`, `${USER_DB}`, `${PASS_DB}`, {
  host: `${IP_DB}`,
  dialect: `${DIALECT_DB}`,
});

sequelize
  .authenticate()
  .then(() => {
    console.log("Connection has been established successfully.");

    app.listen(port, () => {
      console.log("#####################");
      console.log("##### API REST ######");
      console.log("#####################");
      console.log(`http://${IP_SERVER}:${port}/api/${API_VERSION}/`);
    });
  })
  .catch((err) => {
    console.error("Unable to connect to the database:", err);
  });
