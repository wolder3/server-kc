const API_VERSION = "v1";
const API_VERSION2 = "v1";
const IP_SERVER = "localhost";
const IP_DB = "179.61.12.104";
const PORT_DB = "3306";
const DIALECT_DB = "mysql";
const NAME_DB = "kennehco_dbLandingPage";
const USER_DB = "kennehco_admin";
const PASS_DB = "i@pVs+2ocY";
module.exports = {
  API_VERSION,
  IP_SERVER,
  IP_DB,
  PORT_DB,
  DIALECT_DB,
  NAME_DB,
  USER_DB,
  PASS_DB,
};
